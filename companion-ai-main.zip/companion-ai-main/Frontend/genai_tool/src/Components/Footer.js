import React from "react";
const Footer = () => <div>{/* <p>&nbsp;</p> */}</div>;
export default Footer;
